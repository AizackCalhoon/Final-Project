﻿
namespace Calculator_Final_Project
{
    partial class Form1
    {
        /// <summary>
        ///  Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        ///  Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        ///  Required method for Designer support - do not modify
        ///  the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            this.Answer = new System.Windows.Forms.TextBox();
            this.Equals = new System.Windows.Forms.Button();
            this.Addition = new System.Windows.Forms.Button();
            this.Minus = new System.Windows.Forms.Button();
            this.Multiplication = new System.Windows.Forms.Button();
            this.Division = new System.Windows.Forms.Button();
            this.History = new System.Windows.Forms.TextBox();
            this.Precent = new System.Windows.Forms.Button();
            this.Eight = new System.Windows.Forms.Button();
            this.Five = new System.Windows.Forms.Button();
            this.Two = new System.Windows.Forms.Button();
            this.Zero = new System.Windows.Forms.Button();
            this.Twotothex = new System.Windows.Forms.Button();
            this.Seven = new System.Windows.Forms.Button();
            this.Four = new System.Windows.Forms.Button();
            this.One = new System.Windows.Forms.Button();
            this.Pie = new System.Windows.Forms.Button();
            this.Clear = new System.Windows.Forms.Button();
            this.Three = new System.Windows.Forms.Button();
            this.Six = new System.Windows.Forms.Button();
            this.Nine = new System.Windows.Forms.Button();
            this.OneOverX = new System.Windows.Forms.Button();
            this.ySqrx = new System.Windows.Forms.Button();
            this.TentotheX = new System.Windows.Forms.Button();
            this.log2 = new System.Windows.Forms.Button();
            this.Cosh = new System.Windows.Forms.Button();
            this.Cos = new System.Windows.Forms.Button();
            this.CubedRootX = new System.Windows.Forms.Button();
            this.xTotheThird = new System.Windows.Forms.Button();
            this.Logy = new System.Windows.Forms.Button();
            this.Sinh = new System.Windows.Forms.Button();
            this.Sin = new System.Windows.Forms.Button();
            this.fourSquarootx = new System.Windows.Forms.Button();
            this.xToThey = new System.Windows.Forms.Button();
            this.button14 = new System.Windows.Forms.Button();
            this.button15 = new System.Windows.Forms.Button();
            this.log10 = new System.Windows.Forms.Button();
            this.ln = new System.Windows.Forms.Button();
            this.EtotheX = new System.Windows.Forms.Button();
            this.e = new System.Windows.Forms.Button();
            this.Dot = new System.Windows.Forms.Button();
            this.Tanh = new System.Windows.Forms.Button();
            this.Tan = new System.Windows.Forms.Button();
            this.SqrX = new System.Windows.Forms.Button();
            this.xTotheSecond = new System.Windows.Forms.Button();
            this.radical = new System.Windows.Forms.Button();
            this.SuspendLayout();
            // 
            // Answer
            // 
            this.Answer.BackColor = System.Drawing.Color.Black;
            this.Answer.BorderStyle = System.Windows.Forms.BorderStyle.None;
            this.Answer.Font = new System.Drawing.Font("Segoe UI", 27.75F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point);
            this.Answer.ForeColor = System.Drawing.Color.White;
            this.Answer.Location = new System.Drawing.Point(8, 55);
            this.Answer.Multiline = true;
            this.Answer.Name = "Answer";
            this.Answer.PlaceholderText = "0";
            this.Answer.Size = new System.Drawing.Size(728, 50);
            this.Answer.TabIndex = 0;
            this.Answer.TextAlign = System.Windows.Forms.HorizontalAlignment.Right;
            this.Answer.TextChanged += new System.EventHandler(this.Answer_TextChanged);
            // 
            // Equals
            // 
            this.Equals.Location = new System.Drawing.Point(662, 436);
            this.Equals.Name = "Equals";
            this.Equals.Size = new System.Drawing.Size(75, 71);
            this.Equals.TabIndex = 1;
            this.Equals.Text = "=";
            this.Equals.UseVisualStyleBackColor = true;
            this.Equals.Click += new System.EventHandler(this.Equals_Click);
            // 
            // Addition
            // 
            this.Addition.Location = new System.Drawing.Point(662, 359);
            this.Addition.Name = "Addition";
            this.Addition.Size = new System.Drawing.Size(75, 71);
            this.Addition.TabIndex = 2;
            this.Addition.Text = "+";
            this.Addition.UseVisualStyleBackColor = true;
            this.Addition.Click += new System.EventHandler(this.Addition_Click);
            // 
            // Minus
            // 
            this.Minus.Location = new System.Drawing.Point(662, 282);
            this.Minus.Name = "Minus";
            this.Minus.Size = new System.Drawing.Size(75, 71);
            this.Minus.TabIndex = 3;
            this.Minus.Text = "-";
            this.Minus.UseVisualStyleBackColor = true;
            this.Minus.Click += new System.EventHandler(this.Minus_Click);
            // 
            // Multiplication
            // 
            this.Multiplication.Location = new System.Drawing.Point(662, 205);
            this.Multiplication.Name = "Multiplication";
            this.Multiplication.Size = new System.Drawing.Size(75, 71);
            this.Multiplication.TabIndex = 4;
            this.Multiplication.Text = "x";
            this.Multiplication.UseVisualStyleBackColor = true;
            this.Multiplication.Click += new System.EventHandler(this.Multiplication_Click);
            // 
            // Division
            // 
            this.Division.Location = new System.Drawing.Point(662, 128);
            this.Division.Name = "Division";
            this.Division.Size = new System.Drawing.Size(75, 71);
            this.Division.TabIndex = 5;
            this.Division.Text = "/";
            this.Division.UseVisualStyleBackColor = true;
            this.Division.Click += new System.EventHandler(this.Division_Click);
            // 
            // History
            // 
            this.History.BackColor = System.Drawing.Color.Black;
            this.History.BorderStyle = System.Windows.Forms.BorderStyle.None;
            this.History.Font = new System.Drawing.Font("Segoe UI", 15.75F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point);
            this.History.ForeColor = System.Drawing.Color.White;
            this.History.Location = new System.Drawing.Point(13, 21);
            this.History.Name = "History";
            this.History.PlaceholderText = "History";
            this.History.Size = new System.Drawing.Size(724, 28);
            this.History.TabIndex = 6;
            this.History.TextAlign = System.Windows.Forms.HorizontalAlignment.Right;
            this.History.TextChanged += new System.EventHandler(this.History_TextChanged);
            // 
            // Precent
            // 
            this.Precent.Location = new System.Drawing.Point(581, 128);
            this.Precent.Name = "Precent";
            this.Precent.Size = new System.Drawing.Size(75, 71);
            this.Precent.TabIndex = 7;
            this.Precent.Text = "%";
            this.Precent.UseVisualStyleBackColor = true;
            this.Precent.Click += new System.EventHandler(this.Precent_Click);
            // 
            // Eight
            // 
            this.Eight.Location = new System.Drawing.Point(500, 205);
            this.Eight.Name = "Eight";
            this.Eight.Size = new System.Drawing.Size(75, 71);
            this.Eight.TabIndex = 8;
            this.Eight.Text = "8";
            this.Eight.UseVisualStyleBackColor = true;
            this.Eight.Click += new System.EventHandler(this.Eight_Click);
            // 
            // Five
            // 
            this.Five.Location = new System.Drawing.Point(500, 282);
            this.Five.Name = "Five";
            this.Five.Size = new System.Drawing.Size(75, 71);
            this.Five.TabIndex = 9;
            this.Five.Text = "5";
            this.Five.UseVisualStyleBackColor = true;
            this.Five.Click += new System.EventHandler(this.Five_Click);
            // 
            // Two
            // 
            this.Two.Location = new System.Drawing.Point(500, 359);
            this.Two.Name = "Two";
            this.Two.Size = new System.Drawing.Size(75, 71);
            this.Two.TabIndex = 10;
            this.Two.Text = "2";
            this.Two.UseVisualStyleBackColor = true;
            this.Two.Click += new System.EventHandler(this.Two_Click);
            // 
            // Zero
            // 
            this.Zero.Location = new System.Drawing.Point(500, 436);
            this.Zero.Name = "Zero";
            this.Zero.Size = new System.Drawing.Size(156, 71);
            this.Zero.TabIndex = 11;
            this.Zero.Text = "0";
            this.Zero.UseVisualStyleBackColor = true;
            this.Zero.Click += new System.EventHandler(this.Zero_Click);
            // 
            // Twotothex
            // 
            this.Twotothex.Location = new System.Drawing.Point(419, 128);
            this.Twotothex.Name = "Twotothex";
            this.Twotothex.Size = new System.Drawing.Size(75, 71);
            this.Twotothex.TabIndex = 12;
            this.Twotothex.Text = "2^x";
            this.Twotothex.UseVisualStyleBackColor = true;
            this.Twotothex.Click += new System.EventHandler(this.Twotothex_Click);
            // 
            // Seven
            // 
            this.Seven.Location = new System.Drawing.Point(419, 205);
            this.Seven.Name = "Seven";
            this.Seven.Size = new System.Drawing.Size(75, 71);
            this.Seven.TabIndex = 13;
            this.Seven.Text = "7";
            this.Seven.UseVisualStyleBackColor = true;
            this.Seven.Click += new System.EventHandler(this.Seven_Click);
            // 
            // Four
            // 
            this.Four.Location = new System.Drawing.Point(419, 282);
            this.Four.Name = "Four";
            this.Four.Size = new System.Drawing.Size(75, 71);
            this.Four.TabIndex = 14;
            this.Four.Text = "4";
            this.Four.UseVisualStyleBackColor = true;
            this.Four.Click += new System.EventHandler(this.Four_Click);
            // 
            // One
            // 
            this.One.Location = new System.Drawing.Point(419, 359);
            this.One.Name = "One";
            this.One.Size = new System.Drawing.Size(75, 71);
            this.One.TabIndex = 15;
            this.One.Text = "1";
            this.One.UseVisualStyleBackColor = true;
            this.One.Click += new System.EventHandler(this.One_Click);
            // 
            // Pie
            // 
            this.Pie.Location = new System.Drawing.Point(336, 436);
            this.Pie.Name = "Pie";
            this.Pie.Size = new System.Drawing.Size(75, 71);
            this.Pie.TabIndex = 16;
            this.Pie.Text = "Pie";
            this.Pie.UseVisualStyleBackColor = true;
            this.Pie.Click += new System.EventHandler(this.Pie_Click);
            // 
            // Clear
            // 
            this.Clear.Location = new System.Drawing.Point(500, 128);
            this.Clear.Name = "Clear";
            this.Clear.Size = new System.Drawing.Size(75, 71);
            this.Clear.TabIndex = 17;
            this.Clear.Text = "C";
            this.Clear.UseVisualStyleBackColor = true;
            this.Clear.Click += new System.EventHandler(this.Clear_Click);
            // 
            // Three
            // 
            this.Three.Location = new System.Drawing.Point(581, 359);
            this.Three.Name = "Three";
            this.Three.Size = new System.Drawing.Size(75, 71);
            this.Three.TabIndex = 20;
            this.Three.Text = "3";
            this.Three.UseVisualStyleBackColor = true;
            this.Three.Click += new System.EventHandler(this.Three_Click);
            // 
            // Six
            // 
            this.Six.Location = new System.Drawing.Point(581, 282);
            this.Six.Name = "Six";
            this.Six.Size = new System.Drawing.Size(75, 71);
            this.Six.TabIndex = 19;
            this.Six.Text = "6";
            this.Six.UseVisualStyleBackColor = true;
            this.Six.Click += new System.EventHandler(this.Six_Click);
            // 
            // Nine
            // 
            this.Nine.Location = new System.Drawing.Point(581, 205);
            this.Nine.Name = "Nine";
            this.Nine.Size = new System.Drawing.Size(75, 71);
            this.Nine.TabIndex = 18;
            this.Nine.Text = "9";
            this.Nine.UseVisualStyleBackColor = true;
            this.Nine.Click += new System.EventHandler(this.Nine_Click);
            // 
            // OneOverX
            // 
            this.OneOverX.Location = new System.Drawing.Point(255, 359);
            this.OneOverX.Name = "OneOverX";
            this.OneOverX.Size = new System.Drawing.Size(75, 71);
            this.OneOverX.TabIndex = 39;
            this.OneOverX.Text = "1/x";
            this.OneOverX.UseVisualStyleBackColor = true;
            this.OneOverX.Click += new System.EventHandler(this.OneOverX_Click);
            // 
            // ySqrx
            // 
            this.ySqrx.Location = new System.Drawing.Point(255, 282);
            this.ySqrx.Name = "ySqrx";
            this.ySqrx.Size = new System.Drawing.Size(75, 71);
            this.ySqrx.TabIndex = 38;
            this.ySqrx.Text = "ySqr(x)";
            this.ySqrx.UseVisualStyleBackColor = true;
            this.ySqrx.Click += new System.EventHandler(this.ySqrx_Click);
            // 
            // TentotheX
            // 
            this.TentotheX.Location = new System.Drawing.Point(255, 205);
            this.TentotheX.Name = "TentotheX";
            this.TentotheX.Size = new System.Drawing.Size(75, 71);
            this.TentotheX.TabIndex = 37;
            this.TentotheX.Text = "10^x";
            this.TentotheX.UseVisualStyleBackColor = true;
            this.TentotheX.Click += new System.EventHandler(this.TentotheX_Click);
            // 
            // log2
            // 
            this.log2.Location = new System.Drawing.Point(174, 128);
            this.log2.Name = "log2";
            this.log2.Size = new System.Drawing.Size(75, 71);
            this.log2.TabIndex = 36;
            this.log2.Text = "Log2";
            this.log2.UseVisualStyleBackColor = true;
            this.log2.Click += new System.EventHandler(this.log2_Click);
            // 
            // Cosh
            // 
            this.Cosh.Location = new System.Drawing.Point(93, 436);
            this.Cosh.Name = "Cosh";
            this.Cosh.Size = new System.Drawing.Size(75, 71);
            this.Cosh.TabIndex = 35;
            this.Cosh.Text = "Cosh";
            this.Cosh.UseVisualStyleBackColor = true;
            this.Cosh.Click += new System.EventHandler(this.Cosh_Click);
            // 
            // Cos
            // 
            this.Cos.Location = new System.Drawing.Point(93, 359);
            this.Cos.Name = "Cos";
            this.Cos.Size = new System.Drawing.Size(75, 71);
            this.Cos.TabIndex = 34;
            this.Cos.Text = "Cos";
            this.Cos.UseVisualStyleBackColor = true;
            this.Cos.Click += new System.EventHandler(this.Cos_Click);
            // 
            // CubedRootX
            // 
            this.CubedRootX.Location = new System.Drawing.Point(93, 282);
            this.CubedRootX.Name = "CubedRootX";
            this.CubedRootX.Size = new System.Drawing.Size(75, 71);
            this.CubedRootX.TabIndex = 33;
            this.CubedRootX.Text = "3Sqr(x)";
            this.CubedRootX.UseVisualStyleBackColor = true;
            this.CubedRootX.Click += new System.EventHandler(this.CubedRootX_Click);
            // 
            // xTotheThird
            // 
            this.xTotheThird.Location = new System.Drawing.Point(93, 205);
            this.xTotheThird.Name = "xTotheThird";
            this.xTotheThird.Size = new System.Drawing.Size(75, 71);
            this.xTotheThird.TabIndex = 32;
            this.xTotheThird.Text = "x^3";
            this.xTotheThird.UseVisualStyleBackColor = true;
            this.xTotheThird.Click += new System.EventHandler(this.xTotheThird_Click);
            // 
            // Logy
            // 
            this.Logy.Location = new System.Drawing.Point(93, 128);
            this.Logy.Name = "Logy";
            this.Logy.Size = new System.Drawing.Size(75, 71);
            this.Logy.TabIndex = 31;
            this.Logy.Text = "logY";
            this.Logy.UseVisualStyleBackColor = true;
            this.Logy.Click += new System.EventHandler(this.Logy_Click);
            // 
            // Sinh
            // 
            this.Sinh.Location = new System.Drawing.Point(174, 436);
            this.Sinh.Name = "Sinh";
            this.Sinh.Size = new System.Drawing.Size(75, 71);
            this.Sinh.TabIndex = 30;
            this.Sinh.Text = "Sinh";
            this.Sinh.UseVisualStyleBackColor = true;
            this.Sinh.Click += new System.EventHandler(this.Sinh_Click);
            // 
            // Sin
            // 
            this.Sin.Location = new System.Drawing.Point(174, 359);
            this.Sin.Name = "Sin";
            this.Sin.Size = new System.Drawing.Size(75, 71);
            this.Sin.TabIndex = 29;
            this.Sin.Text = "Sin";
            this.Sin.UseVisualStyleBackColor = true;
            this.Sin.Click += new System.EventHandler(this.Sin_Click);
            // 
            // fourSquarootx
            // 
            this.fourSquarootx.Location = new System.Drawing.Point(174, 282);
            this.fourSquarootx.Name = "fourSquarootx";
            this.fourSquarootx.Size = new System.Drawing.Size(75, 71);
            this.fourSquarootx.TabIndex = 28;
            this.fourSquarootx.Text = "4Sqr(x)";
            this.fourSquarootx.UseVisualStyleBackColor = true;
            this.fourSquarootx.Click += new System.EventHandler(this.fourSquarootx_Click);
            // 
            // xToThey
            // 
            this.xToThey.Location = new System.Drawing.Point(174, 205);
            this.xToThey.Name = "xToThey";
            this.xToThey.Size = new System.Drawing.Size(75, 71);
            this.xToThey.TabIndex = 27;
            this.xToThey.Text = "x^y";
            this.xToThey.UseVisualStyleBackColor = true;
            this.xToThey.Click += new System.EventHandler(this.xToThey_Click);
            // 
            // button14
            // 
            this.button14.Location = new System.Drawing.Point(255, 128);
            this.button14.Name = "button14";
            this.button14.Size = new System.Drawing.Size(75, 71);
            this.button14.TabIndex = 26;
            this.button14.Text = "%";
            this.button14.UseVisualStyleBackColor = true;
            // 
            // button15
            // 
            this.button15.Location = new System.Drawing.Point(336, 128);
            this.button15.Name = "button15";
            this.button15.Size = new System.Drawing.Size(75, 71);
            this.button15.TabIndex = 25;
            this.button15.Text = "/";
            this.button15.UseVisualStyleBackColor = true;
            // 
            // log10
            // 
            this.log10.Location = new System.Drawing.Point(336, 205);
            this.log10.Name = "log10";
            this.log10.Size = new System.Drawing.Size(75, 71);
            this.log10.TabIndex = 24;
            this.log10.Text = "Log10";
            this.log10.UseVisualStyleBackColor = true;
            this.log10.Click += new System.EventHandler(this.log10_Click);
            // 
            // ln
            // 
            this.ln.Location = new System.Drawing.Point(336, 282);
            this.ln.Name = "ln";
            this.ln.Size = new System.Drawing.Size(75, 71);
            this.ln.TabIndex = 23;
            this.ln.Text = "ln";
            this.ln.UseVisualStyleBackColor = true;
            this.ln.Click += new System.EventHandler(this.ln_Click);
            // 
            // EtotheX
            // 
            this.EtotheX.Location = new System.Drawing.Point(336, 359);
            this.EtotheX.Name = "EtotheX";
            this.EtotheX.Size = new System.Drawing.Size(75, 71);
            this.EtotheX.TabIndex = 22;
            this.EtotheX.Text = "e^x";
            this.EtotheX.UseVisualStyleBackColor = true;
            this.EtotheX.Click += new System.EventHandler(this.EtotheX_Click);
            // 
            // e
            // 
            this.e.ImageAlign = System.Drawing.ContentAlignment.MiddleRight;
            this.e.Location = new System.Drawing.Point(255, 436);
            this.e.Name = "e";
            this.e.Size = new System.Drawing.Size(75, 71);
            this.e.TabIndex = 21;
            this.e.Text = "e";
            this.e.UseVisualStyleBackColor = true;
            this.e.Click += new System.EventHandler(this.e_Click);
            // 
            // Dot
            // 
            this.Dot.Location = new System.Drawing.Point(417, 436);
            this.Dot.Name = "Dot";
            this.Dot.Size = new System.Drawing.Size(75, 71);
            this.Dot.TabIndex = 40;
            this.Dot.Text = ".";
            this.Dot.UseVisualStyleBackColor = true;
            this.Dot.Click += new System.EventHandler(this.Dot_Click);
            // 
            // Tanh
            // 
            this.Tanh.Location = new System.Drawing.Point(12, 436);
            this.Tanh.Name = "Tanh";
            this.Tanh.Size = new System.Drawing.Size(75, 71);
            this.Tanh.TabIndex = 45;
            this.Tanh.Text = "Tanh";
            this.Tanh.UseVisualStyleBackColor = true;
            this.Tanh.Click += new System.EventHandler(this.Tanh_Click);
            // 
            // Tan
            // 
            this.Tan.Location = new System.Drawing.Point(12, 359);
            this.Tan.Name = "Tan";
            this.Tan.Size = new System.Drawing.Size(75, 71);
            this.Tan.TabIndex = 44;
            this.Tan.Text = "Tan";
            this.Tan.UseVisualStyleBackColor = true;
            this.Tan.Click += new System.EventHandler(this.Tan_Click);
            // 
            // SqrX
            // 
            this.SqrX.Location = new System.Drawing.Point(12, 282);
            this.SqrX.Name = "SqrX";
            this.SqrX.Size = new System.Drawing.Size(75, 71);
            this.SqrX.TabIndex = 43;
            this.SqrX.Text = "2Sqr(x)";
            this.SqrX.UseVisualStyleBackColor = true;
            this.SqrX.Click += new System.EventHandler(this.SqrX_Click);
            // 
            // xTotheSecond
            // 
            this.xTotheSecond.Location = new System.Drawing.Point(12, 205);
            this.xTotheSecond.Name = "xTotheSecond";
            this.xTotheSecond.Size = new System.Drawing.Size(75, 71);
            this.xTotheSecond.TabIndex = 42;
            this.xTotheSecond.Text = "x^2";
            this.xTotheSecond.UseVisualStyleBackColor = true;
            // 
            // radical
            // 
            this.radical.Location = new System.Drawing.Point(12, 128);
            this.radical.Name = "radical";
            this.radical.Size = new System.Drawing.Size(75, 71);
            this.radical.TabIndex = 41;
            this.radical.Text = "x!";
            this.radical.UseVisualStyleBackColor = true;
            this.radical.Click += new System.EventHandler(this.radical_Click);
            // 
            // Form1
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(7F, 15F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.BackColor = System.Drawing.Color.Black;
            this.ClientSize = new System.Drawing.Size(748, 519);
            this.Controls.Add(this.Tanh);
            this.Controls.Add(this.Tan);
            this.Controls.Add(this.SqrX);
            this.Controls.Add(this.xTotheSecond);
            this.Controls.Add(this.radical);
            this.Controls.Add(this.Dot);
            this.Controls.Add(this.OneOverX);
            this.Controls.Add(this.ySqrx);
            this.Controls.Add(this.TentotheX);
            this.Controls.Add(this.log2);
            this.Controls.Add(this.Cosh);
            this.Controls.Add(this.Cos);
            this.Controls.Add(this.CubedRootX);
            this.Controls.Add(this.xTotheThird);
            this.Controls.Add(this.Logy);
            this.Controls.Add(this.Sinh);
            this.Controls.Add(this.Sin);
            this.Controls.Add(this.fourSquarootx);
            this.Controls.Add(this.xToThey);
            this.Controls.Add(this.button14);
            this.Controls.Add(this.button15);
            this.Controls.Add(this.log10);
            this.Controls.Add(this.ln);
            this.Controls.Add(this.EtotheX);
            this.Controls.Add(this.e);
            this.Controls.Add(this.Three);
            this.Controls.Add(this.Six);
            this.Controls.Add(this.Nine);
            this.Controls.Add(this.Clear);
            this.Controls.Add(this.Pie);
            this.Controls.Add(this.One);
            this.Controls.Add(this.Four);
            this.Controls.Add(this.Seven);
            this.Controls.Add(this.Twotothex);
            this.Controls.Add(this.Zero);
            this.Controls.Add(this.Two);
            this.Controls.Add(this.Five);
            this.Controls.Add(this.Eight);
            this.Controls.Add(this.Precent);
            this.Controls.Add(this.History);
            this.Controls.Add(this.Division);
            this.Controls.Add(this.Multiplication);
            this.Controls.Add(this.Minus);
            this.Controls.Add(this.Addition);
            this.Controls.Add(this.Equals);
            this.Controls.Add(this.Answer);
            this.Name = "Form1";
            this.StartPosition = System.Windows.Forms.FormStartPosition.CenterScreen;
            this.Text = "Scientific Calculator";
            this.Load += new System.EventHandler(this.Form1_Load);
            this.ResumeLayout(false);
            this.PerformLayout();

        }

        #endregion

        private System.Windows.Forms.TextBox Answer;
        private System.Windows.Forms.Button Equals;
        private System.Windows.Forms.Button Addition;
        private System.Windows.Forms.Button Minus;
        private System.Windows.Forms.Button Multiplication;
        private System.Windows.Forms.Button Division;
        private System.Windows.Forms.TextBox History;
        private System.Windows.Forms.Button Precent;
        private System.Windows.Forms.Button Eight;
        private System.Windows.Forms.Button Five;
        private System.Windows.Forms.Button Two;
        private System.Windows.Forms.Button Zero;
        private System.Windows.Forms.Button Twotothex;
        private System.Windows.Forms.Button Seven;
        private System.Windows.Forms.Button Four;
        private System.Windows.Forms.Button One;
        private System.Windows.Forms.Button Pie;
        private System.Windows.Forms.Button Clear;
        private System.Windows.Forms.Button Three;
        private System.Windows.Forms.Button Six;
        private System.Windows.Forms.Button Nine;
        private System.Windows.Forms.Button OneOverX;
        private System.Windows.Forms.Button ySqrx;
        private System.Windows.Forms.Button TentotheX;
        private System.Windows.Forms.Button log2;
        private System.Windows.Forms.Button Cosh;
        private System.Windows.Forms.Button Cos;
        private System.Windows.Forms.Button CubedRootX;
        private System.Windows.Forms.Button xTotheThird;
        private System.Windows.Forms.Button Logy;
        private System.Windows.Forms.Button Sinh;
        private System.Windows.Forms.Button Sin;
        private System.Windows.Forms.Button fourSquarootx;
        private System.Windows.Forms.Button xToThey;
        private System.Windows.Forms.Button button14;
        private System.Windows.Forms.Button button15;
        private System.Windows.Forms.Button log10;
        private System.Windows.Forms.Button ln;
        private System.Windows.Forms.Button button18;
        private System.Windows.Forms.Button e;
        private System.Windows.Forms.Button Dot;
        private System.Windows.Forms.Button Tanh;
        private System.Windows.Forms.Button Tan;
        private System.Windows.Forms.Button SqrX;
        private System.Windows.Forms.Button xTotheSecond;
        private System.Windows.Forms.Button radical;
        private System.Windows.Forms.Button EtotheX;
    }
}

